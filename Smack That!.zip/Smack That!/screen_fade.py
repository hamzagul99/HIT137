import pygame 


class ScreenFade():
	def __init__(self, direction, colour, speed, screen, SCREEN_WIDTH, SCREEN_HEIGHT):
		self.direction = direction
		self.colour = colour
		self.speed = speed
		self.fade_counter = 0
		self.screen = screen
		self.SCREEN_WIDTH = SCREEN_WIDTH
		self.SCREEN_HEIGHT = SCREEN_HEIGHT


	def fade(self):
		fade_complete = False
		self.fade_counter += self.speed
		if self.direction == 1:
			pygame.draw.rect(self.screen, self.colour, (0 - self.fade_counter, 0, self.SCREEN_WIDTH // 2, self.SCREEN_HEIGHT))
			pygame.draw.rect(self.screen, self.colour, (self.SCREEN_WIDTH // 2 + self.fade_counter, 0, self.SCREEN_WIDTH, self.SCREEN_HEIGHT))
			pygame.draw.rect(self.screen, self.colour, (0, 0 - self.fade_counter, self.SCREEN_WIDTH, self.SCREEN_HEIGHT // 2))
			pygame.draw.rect(self.screen, self.colour, (0, self.SCREEN_HEIGHT // 2 +self.fade_counter, self.SCREEN_WIDTH, self.SCREEN_HEIGHT))
			
		if self.direction == 2:
			pygame.draw.rect(self.screen, self.colour, (0, 0, self.SCREEN_WIDTH, 0 + self.fade_counter))
		if self.fade_counter >= self.SCREEN_WIDTH:
			fade_complete = True

		return fade_complete