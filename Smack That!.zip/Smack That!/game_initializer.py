import pygame
from constants import *
from pygame import mixer


mixer.init()
pygame.init()
screen = pygame.display.set_mode((WIDTH, HEIGHT))
pygame.display.set_caption('Smack That!')
font = pygame.font.SysFont('Futura', 30)

def draw_text(text, font, text_col, x, y):
	img = font.render(text, True, text_col)
	screen.blit(img, (x, y))

def load_audio():
    pygame.mixer.music.load('audio/music.wav')
    pygame.mixer.music.set_volume(0.2)
    pygame.mixer.music.play(-1, 0.0, 5000)
    jump_fx = pygame.mixer.Sound('audio/jump.wav')
    jump_fx.set_volume(0.05)
    shot_fx = pygame.mixer.Sound('audio/shot.mp3')
    shot_fx.set_volume(0.05)
    grenade_fx = pygame.mixer.Sound('audio/grenade.wav')
    grenade_fx.set_volume(0.05)
    return jump_fx, shot_fx, grenade_fx

def load_imgs():
    start_img = pygame.image.load('img/start_btn.png').convert_alpha()
    exit_img = pygame.image.load('img/exit_btn.png').convert_alpha()
    restart_img = pygame.image.load('img/restart_btn.png').convert_alpha()
    pine1_img = pygame.image.load('img/Background/pine1.png').convert_alpha()
    pine2_img = pygame.image.load('img/Background/pine2.png').convert_alpha()
    mountain_img = pygame.image.load('img/Background/mountain.png').convert_alpha()
    sky_img = pygame.image.load('img/Background/sky_cloud.png').convert_alpha()
    bullet_img = pygame.image.load('img/icons/bullet.png').convert_alpha()
    grenade_img = pygame.image.load('img/icons/grenade.png').convert_alpha()
    health_box_img = pygame.image.load('img/icons/health_box.png').convert_alpha()
    ammo_box_img = pygame.image.load('img/icons/ammo_box.png').convert_alpha()
    grenade_box_img = pygame.image.load('img/icons/grenade_box.png').convert_alpha()
	
    return start_img, exit_img, restart_img, pine1_img, pine2_img, mountain_img, sky_img, bullet_img, grenade_img, health_box_img, ammo_box_img, grenade_box_img

start_img, exit_img, restart_img, pine1_img, pine2_img, mountain_img, sky_img, bullet_img, grenade_img, health_box_img, ammo_box_img, grenade_box_img = load_imgs()

img_list = []
for x in range(TILE_TYPES):
	img = pygame.image.load(f'img/Tile/{x}.png')
	img = pygame.transform.scale(img, (TILE_SIZE, TILE_SIZE))
	img_list.append(img)


item_boxes = {
	'Health' : health_box_img,
	'Ammo' : ammo_box_img,
	'Grenade' : grenade_box_img
}

def draw_bg():
	screen.fill(WHITE)
	width = sky_img.get_width()
	for x in range(5):
		screen.blit(sky_img, ((x * width) - bg_scroll * 0.5, 0))
		screen.blit(mountain_img, ((x * width) - bg_scroll * 0.6, HEIGHT - mountain_img.get_height() - 300))
		screen.blit(pine1_img, ((x * width) - bg_scroll * 0.7, HEIGHT - pine1_img.get_height() - 150))
		screen.blit(pine2_img, ((x * width) - bg_scroll * 0.8, HEIGHT - pine2_img.get_height()))


clock = pygame.time.Clock()
FPS = 60

