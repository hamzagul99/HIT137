import tkinter as tk
from tkinter import filedialog
from PIL import Image, ImageTk, ImageDraw
from ultralytics import YOLO

class ObjectDetectionApp(tk.Tk):
    def __init__(self):
        super().__init__()

        self.title("Person Detection App")
        self.geometry("1000x1000")

        self.configure(bg='lightgray')

        original_frame = tk.Frame(self, bg='lightgray')
        original_frame.pack(side=tk.LEFT, padx=10, pady=10)

        self.canvas_original = tk.Canvas(original_frame, width=400, height=800, bg='white')
        self.canvas_original.pack()

        self.filename_label = tk.Label(original_frame, text="Original Image", bg='lightgray', fg='blue')
        self.filename_label.pack(pady=5)


        detected_frame = tk.Frame(self, bg='lightgray')
        detected_frame.pack(side=tk.RIGHT, padx=10, pady=10)

        self.canvas_detected = tk.Canvas(detected_frame, width=400, height=800, bg='white')
        self.canvas_detected.pack()

        self.detected_label = tk.Label(detected_frame, text="Person Detected", bg='lightgray', fg='blue')
        self.detected_label.pack(pady=5)


        self.btn_open = tk.Button(self, text="Open Image", command=self.open_image, bg='lightgray')
        self.btn_open.pack(pady=400)


        self.original_image_tk = None
        self.detected_image_tk = None

    def open_image(self):
        global file_path
        f_types = [('Jpg Files', '*.jpg'), ('PNG Files', '*.png')]
        file_path = filedialog.askopenfilename(title="Select Image", filetypes=f_types)

        if file_path:
            original_image = self.load_image(file_path)
            self.display_original_image(original_image)

            objects = self.detect_objects(file_path)
            self.display_detected_image(objects)

    def load_image(self, file_path):

        img = Image.open(file_path)
        img.thumbnail((800, 800))
        self.original_image_tk = ImageTk.PhotoImage(img)
        return self.original_image_tk

    def detect_objects(self, file_path):

        yolo = YOLO("yolov8n.pt")

        objects = yolo(file_path, classes=0)

        return objects

    def display_original_image(self, image):
        self.canvas_original.delete("all")
        self.canvas_original.create_image(0, 0, anchor=tk.NW, image=image)


        filename = file_path.split("/")[-1]
        self.filename_label.config(text=f"Original Image: {filename}")

    def display_detected_image(self, objects):

        detected_img = Image.open(file_path).copy()
        draw = ImageDraw.Draw(detected_img)


        for obj in objects:
            if len(obj.boxes.xyxy) > 0:
                box = obj.boxes.xyxy[0].tolist()
                draw.rectangle(box, outline='red', width=2)

        self.detected_image_tk = ImageTk.PhotoImage(detected_img)

        self.canvas_detected.delete("all")
        self.canvas_detected.create_image(0, 0, anchor=tk.NW, image=self.detected_image_tk)

        detected_obj = "YES" if len(objects[0].boxes.cls) > 0 else "NO"
        self.detected_label.config(text=f"Person Detected: {detected_obj}")

if __name__ == "__main__":
    app = ObjectDetectionApp()
    app.mainloop()
